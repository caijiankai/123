package cn.easybuy.dao;
import cn.easybuy.utils.Params;

import java.sql.ResultSet;
import java.util.List;
import java.util.Map;

/**
 * Created by bdqn on 2016/4/22.
 */
public interface IBaseDao {
//	/**
//	 * 查询单表的数目
//	 * @param  params
//	 * @return 
//	 * @throws Exception
//	 */
//    public int getRowCount(Params params) throws Exception;
//    /**
//     * 查询单表的列表
//     * @param params
//     * @return
//     * @throws Exception
//     */
//    public List getRowList(Params params)throws Exception;
//    /**
//     * 每一个dao都需要重写的tableName
//     * @return
//     */
//    public String getTableName();
//    /**
//     * 根据id获取对象
//     * @param id
//     * @return
//     * @throws Exception
//     */
//    public Object getById(Integer id) throws Exception;
//    /**
//     * 根据参数更新对象
//     * @param params
//     * @throws Exception
//     */
//    public void updateByQuery(Params params) throws Exception;
//    /**
//     * 根据参数添加对象
//     * @param params
//     * @return
//     * @throws Exception
//     */
//    public Integer addObject(Params params)throws Exception;
//    /**
//     * 根据 id 删除记录
//     * @param id
//     * @throws Exception
//     */
//    public void deleteById(Integer id) throws Exception;
//    /**
//     * 自定义sql的方法
//     * @param sql
//     * @param params
//     */
//    public List selectBySql(String sqlStr,Params query)throws Exception;
}
