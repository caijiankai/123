create table `result`(
		`studentNo` int (4) not null comment '学号',
        `subjectNo` int (4) not null comment '课程编号',
        `examDate` datetime not null comment '考试日期',
        `studentResult`int(4) not null

);