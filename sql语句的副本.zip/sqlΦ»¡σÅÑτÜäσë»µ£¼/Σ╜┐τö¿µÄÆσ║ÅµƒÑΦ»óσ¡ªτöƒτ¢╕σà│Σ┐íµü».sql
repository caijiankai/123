#使用排序查询学生相关信息
#按照出生日期倒序查询1年级的学生信息
SELECT *FROM student 
WHERE gradeId=1
order by bornDate desc;
#按日期先后,成绩由高到低的次序查询Logic Java 的科目考试信息
select *from `subject`
where subjectName='JAVA' and score='90';
use myschool;
select * from `student`
where gradeId='1'
order by bornDate;
#查询2013年3月22日参加“Java OOP”考试的前5名学生的成绩信息
select * from student where subjectName='Java OOP' and examdate=2013-03-22;
#查询1年级课时最多的科目名称
SELECT  `subjectName` from `subject` where `classhour`>200;
#查询年龄最小的学生姓名及所在的年级
select min(age),studentName from student;
#查询2013年3月22日参加考试的最低分出现在哪个科目
select min(score) `subject` from `subject` where examdate=2013-03-22;
#查询学号为10000的学生参加过的所有考试信息,并按照时间先后次序显示
select 
