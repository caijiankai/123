#limit子句
select `studentNo`,`studentName`,`phone`,`address`,`bornDate`
from `student`
where `gradeId`=1
order by studentNo
limit 4;
select `studentNo`,`studentName`,`phone`,`address`,`bornDate`
from `student`
where `gradeId`=1
order by studentNo
limit 4,4;
