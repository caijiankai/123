#常用函数
#聚合函数 AVG()返回某字段的平均值  COUNT() 返回某字段的行数 MAX() 返回某字段的最大值
#MIN()返回某字段的最小值  SUM() 返回某字段的和
SELECT SUM(studentResult) FROM result;
SELECT AVG(studentResult)FROM result;
#2.字符串的函数
#CONCAT(str,str1,...,str)连接字符串,INSERT(str,pos,newstr),LOWER(str),
#UPPER(str),SUBSTRING(str,num,len)返回字符串str的第num个位置开始长度为len的子字符串
#3.时间日期函数
#CURDATE()获取当前日期 ,CURTIME() 获取当前时间,NOW() 获取当前日期和时间
#WEEK(date) 返回日期date为一年中的第几周,YEAR(date) 返回日期date的年份
#HOUR(time)返回时间time的小时值
#MINUTE(time)返回时间time的分钟值 
#DATEDIFF(date1,date2)返回日期参数date1和date2之间相隔的天数
#ADDDATE(date,n)计算日期参数date加上n天后的日期
#数学函数
#CEIL(x) 返回大于或等于数值x的最小整数  FLOOR(x) 返回小雨或等于数值x的最大整数
#RAND() 返回0~1·间的随机数