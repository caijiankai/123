#查询'李'姓老师的数量
select  count(*) from Teacher
where substring(tname,1,1)='李';
select count(*) from teacher
where tname like'李%';


#查询学过'张三'老师授课的学生信息\
	use test;
	select Course.C,SC.C ,Teacher.T from Course,SC
    inner join Teacher
    where Course.C=SC.C
    and Teacher.Tname='张三';
     
    #查询张三老师的教师编号  为01
    select * from Teacher where Tname='张三';
    #查询教师编号为01的上课学生课程编号 为02
    select * from Course where T='01';
    #查询成绩表中课程编号为02 的学生编号
    select S from SC where Cvar ='02';
    
    SELECT * from Student1 where Student1.S  not in(
    select S from SC where C =(
    select C from Course where T=(select  T from Teacher where Tname='张三')));
    #另一种方法
    USE TEST;
    select a.* from Student1 a 
    inner join SC b on a.`S`=b.`S`
    inner join Course c on b.`Cvar`=c.`C`
    inner join Teacher d on c.t=d.t
    where d.Tname='张三';
    #9.查询学过编号为01的课程,并且也学过编号为02课程的同学的信息
    select *from Student1 
    inner join Course 
    inner join SC 
    where Course.C=SC.C
    and Course.C='01';
    #9查询课程表编号为01 02的学生编号
	SELECT *FROM Student1 WHERE Student1.S IN (
	SELECT temp1.S FROM 
	(SELECT * FROM SC
	GROUP BY C,S
	HAVING C='01') AS temp1  
	,
	(SELECT * FROM SC
	GROUP BY C,S
	HAVING C='02') AS temp2
	WHERE temp1.S=temp2.S);



    #10.查询学过编号为01课程,但没有学过编为02课程的同学的信息
	select *from Student1 a
    left join SC b on
    a.`S`=b.`S` and b.`C`='01'
    left join SC c on 
    a.`S`=c.`S` and c.`C`='02'
    where b.`C`='01' and c.`C` is null;
 
    #11.查询没有学全所有课程的同学的信息
		/*#查课程编号的数目
		select  max(C) from Course;
		#查小于课程编号3的学生编号
        select S from SC where SC.Cvar<>(select  max(C) from Course);
        #查询学生信息
        select * from Student1 where 
        Student1.S  IN (select S from SC where SC.Cvar<>(select  max(C) from Course));
        */
        
        select a.* from Student1 a
        left join SC b on 
        a.`S`=b.`S`
        group by 1,2,3,4
        having count(b.C)<(select count(1) from Course);
        
       
 
    
    #12.查询至少有一门课与学号为“01”的同学所学的相同的同学的信息
			#错误做法
		   select a.* from Student1 a
           inner join SC b on 
           a.`S` =b.`S`
           where exists(
				select * from SC where S='01'  and `C`=b.`C `     
                )
			group by 1,2,3,4
			having a.`S`<>'01';
    
    #13.查询和“01”号的同学学习的课程完全的相同的其他同学的信息
			##错误做法1
			#查询01号同学学习的课编号
            select Cvar from SC where S='01';
            #查询学过课程编号1,2,3的其他同学的学生编号
            select S from SC
            INNER JOIN SC as a
            INNER JOIN SC as b
            INNER JOIN SC as d
            on a.Cvar=01 and b.Cvar=02;
            ##另一种做法
            select a.*,b.`C` from Student1 a
            inner join SC b on a.`S`=b.`S`
            where C in(select C from SC where S='01')
            group by 1,2,3,4
            having count(1)=(select count(1) from SC  where S='01');
 
            #老师做法
            select a.*,sum(case when exists(
				select 1 from SC where S='01' and C=b.`C`
            ) then 1 else 0 end) as asum,count(b.`C`) bsum
            from Student1 a
            inner join SC b on a.`S`=b.`S`
            group by 1,2,3,4
            having asum=(select count(1) from SC where S='01') and a.`S`<>'01'
				and asum=bsum;
            
			#错误做法3
            select S from SC WHERE Cvar in (select Cvar from SC where S='01')
            group by S
            HAVING S <>'01';
            #查询和01号学生学的相同的课程的学生
            select * from Student1 where S in (
				 select S from SC WHERE Cvar in (select Cvar from SC where S='01')
            group by S
            HAVING S <>'01'
            );
		
    #14.查询两门及其以上不及格课程的同学的学号,姓名及平均成绩
			#查询两门及其以上不及格课程的同学的学号
            #自己的做法
				select a.S,a.Sname,avg(score) from  Student1 a
				inner join SC b
                on a.S=b.S AND b.score<'60'
                group by a.S
                having count(*)>=2;
		
    #15.检索01课程的分数小于60,按分数降序排列学生信息
			#错误做法
			select Student1.*,SC.score from Student1 
            inner join SC 
            on Student1.S=SC.S
            where a.S IN(
			select S from SC  where C='01' and score<'60'
            order by b.score desc);
            #另一种做法
            select SC.score,Student1.* from SC
            inner join Student1
            on SC.S=Student1.S
            where SC.score<60 and C='01'
            order by (SC.score) DESC;
            #16.按平均成绩从高到低显示所有学生的所有课程的总成绩以及平均成绩
                    #查询所有学生的编号的平均成绩,总成绩
                     select sum(score),avg(score),S from SC
                     where S='01';
                     select sum(score),avg(score)  from SC
                     where S='02' ;
                     select sum(score),avg(score)  from SC
                     where S='03' ;
                     select sum(score),avg(score)  from SC
                     where S='04'; 
                     select sum(score),avg(score)  from SC
                     where S='05'; 
                     select sum(score),avg(score)  from SC
                     where S='06' ;
                     select sum(score),avg(score) from SC
                     where S='07'; 
                     
                     #正确做法
					 select st.*,sum(a.score) as 总成绩,avg(a.score) 平均成绩 from SC as a
                     inner join Student1 st 
                     on st.`S`=a.`S`
                     group by a.`S`
                     order by avg(a.score) desc;

            #17.查询各科成绩最高分、最低分、和平均分:以如下形式显示
            #课程ID、课程name、最高分、最低分、平均分、及格率、中等率、优良率、优秀率、
            #及格为>=60,中等为70-80(含70不含80)优良80-90(含80不含90)优秀>=90
               #查询各科目的课程ID
               select C as '课程ID' from SC ;
               #查询课程name
               select Cname as '课程name' from SC 
               inner join Course b
               on a.C=b.C
               group by b.C;
               #查询各科最高分
               select max(score) from SC 
               inner join Course
               on SC.C IN(select C as '课程ID' from SC) ;
               #老师做法
               select a.C,a.Cname,
               max(b.`score`) 最大分,
               min(b.`score`) 最低分,
               avg(b.`score`) 平均分,
               sum(case when b.`score`>=60 then 1 else 0 end)/count(1) 及格率,
               sum(case when b.`score`>=70 and b.`score`<80 then 1 else 0 end)/count(1) 中等率,
               sum(case when b.`score`>=80 and b.`score`<90 then 1 else 0 end)/count(1) 优秀率
               from Course a 
               inner join  SC b on a.`C`=b.`C`
               group by 1,2;
               
            #18.按各科成绩进行排序,并显示排名
					#查询各科的编号
                    select c from sc
                    group by c;
                    #查询各科成绩
                    select c as'各科成绩',sum(score)from sc
                    group by c;
                     #进行排序,
                    select c as'各科成绩',sum(score)from sc
                    group by c
                    order by sum(score)  desc;
                    #老师做法
                    set @sn:=0;
                    select @sn:=@sn+1,aa.*from(          
                    select a.c,a.cname,sum(b.`score`) asum
                    from Course a 
                    inner join SC b on a.c=b.`c`
                    group by 1,2
                    order by asum desc     
                    )aa;
          
            #19.查询学生的总成绩并进行排名
					#查询编号学生的总成绩
                    select s, sum(score)from sc 
                    group by s;
                    #进行显示姓名
                    select Sname from Student1 a 
                    inner join sc b
                    on a.s=b.s
                    group by Sname;
                    #查询各编号对应的学生姓名
                    
                    
			#20.查询不同老师所教课程的平均分从高到低显示
                   
                   select avg(score) '平均分',b.Tname from SC a
                   inner join Teacher b
                   inner join Course c
                   on b.T=c.T;
					
                    
                    #查询老师的编号
                    select T from Teacher a;
                    #查询老师对应的课程编号
                    
                  #孙辉做法
                  select t.Tname,c.Cname,(sum(SC.score)) / (select count(*) from SC sc1
                  where sc1.c=sc.c) as '平均分' from Teacher t,Course c,SC sc 
                  where t.T=c.T and SC.C=c.C
                  group by SC.C
                  order by '平均分' desc;
                  
                  
      
            #21.查询所有课程的成绩第2名和第3名的学生信息及该课程成绩
					#查询01课程的成绩第2名和第3名
                    select * from sc
                    where c='01'           
                    group by score 
                    order by score desc  
                    limit 1,2;
                    
                    #
                    select a.score,b.* from sc as a
                    inner join Student1  as b 
                    on a.S=b.S
                    where a.c='01'           
                    group by score 
                    order by score desc  
                    limit 1,2
                    
                    
                    
                    
                    
								
                 
                 
                 
                     
                    
                    
    
    
    
    
    
    
    
    
    

