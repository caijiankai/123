

select studentNo as 学生编号,(studentResult*0.9+5) as 综合成绩
from result
where (studentResult*0.9+5)>60
order by studentResult;
