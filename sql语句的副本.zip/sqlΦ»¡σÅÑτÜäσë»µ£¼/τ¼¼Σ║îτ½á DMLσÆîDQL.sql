SELECT * FROM myschool.result;
select subjectNo,avg(studentResult) as 课程平均成绩
from result
group by subjectNo;
select count(*) as 人数,grade as 年级,sex as 性别 from student
group by grade,sex
order by grade;
select *from student;
select studentNo,studentName,address from student where studentNo=1003;
select studentNo,studentName,address from student where studentNo<>1003;
select studentNo as `学生编号`,studentName as 学生姓名,address as 学生地址
from student
where address='威海环翠区';
select studentNo +studentName as 学生姓名
from student
where address='威海环翠区';
select studentName from student where email is null;

