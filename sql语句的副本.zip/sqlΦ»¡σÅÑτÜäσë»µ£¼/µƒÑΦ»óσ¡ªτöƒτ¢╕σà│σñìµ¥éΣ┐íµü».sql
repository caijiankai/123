#使用SELECT 语句查询数据
#查询一年级的科目名称
desc `subject`;
SELECT `subjectName`,`gradeId` FROM `subject`
WHERE gradeId=1;
#查询2年级所有男同学的姓名和地址
SELECT *FROM `student`WHERE gradeId=2 and sex='男';
#查询无电子邮件的学生姓名和年级信息
SELECT *FROM `student` WHERE `email` is null;
#查询2年级并在HTML科目考试的所有学员信息
SELECT *FROM `student` WHERE gradeId=2 and bornDate >1990;
#查询参加了HTML科目考试的所有学员成绩
SELECT *FROM `student` AS s
inner join `subject` AS su on(s.studentNo=su.studentNo)
where subjectName='HTML';