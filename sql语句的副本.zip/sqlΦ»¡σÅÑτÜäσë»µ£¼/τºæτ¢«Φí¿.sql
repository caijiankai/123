create table `subject`(
			`subjectNo` int(4) not null primary key comment '课程编号',
            `subjectName`varchar (50) comment '课程名称',
            `classHour` int (4)  comment '学时',
            `gradeId` int(4) comment '年级编号'
);