SELECT * FROM myschool.student;
select `studentNo` from `student` where `studentNo`=(
		SELECT `studentNo` FROM `result`
        inner join `subject` on result.subjectNo=`subject`.subjectNo
        where 	 `subjectName`='Java'                                                                           
);
