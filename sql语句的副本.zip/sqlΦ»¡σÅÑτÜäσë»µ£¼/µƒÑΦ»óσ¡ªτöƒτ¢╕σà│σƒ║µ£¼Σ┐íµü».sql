#查询1年级的全部学生信息
select *from student where gradeId=1;
#查询2年级的全部学生的姓名和电话
select*from student where gradeId=2;
#查询1年级的全部女同学的信息
select*from student where gradeId=1 and sex='女';
#查询课时超过200的科目信息
